package model;

import beans.Artist;

public interface ArtistDao extends GenericDao<Artist, Integer>{
	}
	
