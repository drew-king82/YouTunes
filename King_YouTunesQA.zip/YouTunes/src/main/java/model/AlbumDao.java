package model;

import beans.Album;

public interface AlbumDao extends GenericDao<Album, Integer>{
	}
	
